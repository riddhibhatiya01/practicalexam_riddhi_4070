// src/components/UserList.js

import React, { useState, useEffect } from "react";
import { getUsers, deleteUser } from "../services/api";
import "../styles.css";

const UserList = () => {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(5);

  useEffect(() => {
    fetchUsers();
  }, [search, page, recordsPerPage]);

  const fetchUsers = async () => {
    const data = await getUsers(search);
    setUsers(data.filter(user => user.status !== false)); // Soft delete filter
  };

  const handleDelete = async (id) => {
    await deleteUser(id, false);
    fetchUsers();
  };

  const handleSearch = (e) => {
    setSearch(e.target.value);
    setPage(1);
  };

  const indexOfLastRecord = page * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const currentRecords = users.slice(indexOfFirstRecord, indexOfLastRecord);

  return (
    <div className="container">
      <h2>User List</h2>
      <input
        type="text"
        placeholder="Search by Name, Email, Phone"
        value={search}
        onChange={handleSearch}
      />
      <select onChange={(e) => setRecordsPerPage(Number(e.target.value))}>
        <option value="5">5</option>
        <option value="10">10</option>
        <option value="15">15</option>
      </select>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Image</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {currentRecords.map((user, index) => (
            <tr key={index}>
              <td>{user.id}</td>
              <td><img src={user.image} alt={user.name} className="user-img" /></td>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.phone}</td>
              <td>
                <button className="delete-btn" onClick={() => handleDelete(user.id)}>
                  🗑️
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="pagination">
        <button onClick={() => setPage(page - 1)} disabled={page === 1}>Prev</button>
        <span>{page}</span>
        <button onClick={() => setPage(page + 1)} disabled={indexOfLastRecord >= users.length}>Next</button>
      </div>
    </div>
  );
};

export default UserList;
