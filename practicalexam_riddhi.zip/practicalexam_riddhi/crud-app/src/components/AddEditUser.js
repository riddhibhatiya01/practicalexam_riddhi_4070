// src/components/AddEditUser.js

import React, { useState, useEffect } from "react";
import { addUser, updateUser, getUserById } from "../services/api";
import { useParams, useNavigate } from "react-router-dom";
import "../styles.css";

const AddEditUser = () => {
  const [user, setUser] = useState({ name: "", email: "", phone: "", image: "", status: true });
  const [errors, setErrors] = useState({});
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      fetchUser(id);
    }
  }, [id]);

  const fetchUser = async (userId) => {
    const data = await getUserById(userId);
    setUser(data);
  };

  const validate = () => {
    let tempErrors = {};
    if (!user.name || user.name.length < 3) tempErrors.name = "At least 3 characters required";
    if (!user.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(user.email)) tempErrors.email = "Enter a valid email";
    if (!user.phone || !/^[0-9]+$/.test(user.phone)) tempErrors.phone = "Only numbers allowed";
    if (!user.image) tempErrors.image = "Image URL required";
    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    id ? await updateUser(id, user) : await addUser(user);
    navigate("/");
  };

  return (
    <div className="container">
      <h2>{id ? "Edit" : "Add"} User</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Name" value={user.name} onChange={handleChange} />
        {errors.name && <span className="error">{errors.name}</span>}
        
        <input type="email" name="email" placeholder="Email" value={user.email} onChange={handleChange} />
        {errors.email && <span className="error">{errors.email}</span>}
        
        <input type="text" name="phone" placeholder="Phone" value={user.phone} onChange={handleChange} />
        {errors.phone && <span className="error">{errors.phone}</span>}
        
        <input type="text" name="image" placeholder="Image URL" value={user.image} onChange={handleChange} />
        {errors.image && <span className="error">{errors.image}</span>}
        
        <button type="submit">{id ? "Update" : "Add"} User</button>
      </form>
    </div>
  );
};

export default AddEditUser;
