// src/services/api.js

const API_URL = "http://localhost:5000/users";

// Fetch all users
export const getUsers = async (query = "") => {
  const response = await fetch(`${API_URL}?q=${query}`);
  return response.json();
};

// Fetch user by ID
export const getUserById = async (id) => {
  const response = await fetch(`${API_URL}/${id}`);
  return response.json();
};

// Add a new user
export const addUser = async (user) => {
  await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(user),
  });
};

// Update user
export const updateUser = async (id, user) => {
  await fetch(`${API_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(user),
  });
};

// Soft delete user
export const deleteUser = async (id, status) => {
  await fetch(`${API_URL}/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status })
  });
};
