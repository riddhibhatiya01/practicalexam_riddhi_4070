// src/App.js

import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import UserList from "./components/UserList";
import AddEditUser from "./components/AddEditUser";
import "./styles.css";

const App = () => {
  return (
    <Router>
      <div className="app-container">
        <nav>
          <Link to="/">User List</Link>
          <Link to="/add">Add User</Link>
        </nav>
        <Routes>
          <Route path="/" element={<UserList />} />
          <Route path="/add" element={<AddEditUser />} />
          <Route path="/edit/:id" element={<AddEditUser />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
